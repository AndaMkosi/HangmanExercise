

import java.util.*;

//import static java.util.Arrays.fill;

public class Hangman{


    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Player One, enter a word:");
        char[] wordToGuess = (sc.next()).toCharArray();
        char[] displayWord = new char[wordToGuess.length];
        Arrays.fill(displayWord,'_');
        int chances = 8;
        char[] guess;
        //System.out.println("Player Two, you have "+chances+" guesses left. Enter a guess:");

        while(true){
            System.out.println(String.valueOf(displayWord));
            System.out.println("Player Two, you have "+chances+" guesses left. Enter a guess:");
            guess=(sc.next()).toCharArray();
            int count =0;
            if(guess.length==1){
                if(String.valueOf(displayWord).contains(String.valueOf(guess[0]))){
                    System.out.println("You have already guessed '" + guess[0] + "'.");
                    count++;
                }else{
                    for(int i =0;i<wordToGuess.length;i++){
                        if(guess[0]==wordToGuess[i]){
                            displayWord[i]=wordToGuess[i];
                            count++;
                        }
                    }
                }
                //check if the counter is greater than zero;
                if(count==0){
                    chances--;
                }else {
                    //The chances remain constant
                }
                //before exiting the if block statement,
                // the counter is set back to zero, NB: this is optional in this case
                count=0;

            }else{
                for(int i=0;i<guess.length;i++){
                    if(String.valueOf(displayWord).contains(String.valueOf(guess[i]))){
                        //System.out.println("You have already guessed '" + guess[0] + "'.");
                        count++;
                    }else{
                        for(int k =0;k<wordToGuess.length;k++){
                            if(guess[i]==wordToGuess[k]){
                                displayWord[k]=wordToGuess[k];
                                count++;
                            }
                        }
                    }
                    //check if the counter is greater than zero;
                    if(count==0){
                        chances--;
                    }else {
                        //The chances remain constant
                    }
                    //before going to the next iteration,
                    // the counter is set back to zero.

                    count=0;

                }
                chances++;

            }

            //These are the conditions to break out of the while loop.

            if(String.valueOf(wordToGuess).equals(String.valueOf(displayWord))){
                System.out.println(String.valueOf(wordToGuess));
                System.out.println("Game over. Player Two wins!");
                // do something
                break;

            }else if(chances<=0){
                // do something
                System.out.println("Game over. Player One wins! The word was: "+String.valueOf(wordToGuess));
                break;
            }else{
                //if()

            }
        }
    }


}